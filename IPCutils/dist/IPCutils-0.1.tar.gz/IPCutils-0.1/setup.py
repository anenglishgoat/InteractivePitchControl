from setuptools import setup

setup(name='IPCutils',
      version='0.1',
      description='',
      url='',
      author='Will Thomson',
      author_email='',
      license='AGPL-3',
      packages=['IPCutils'],
      zip_safe=False)